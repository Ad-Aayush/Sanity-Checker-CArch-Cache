
#include "simulator.h"
#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

int main()
{
    cache *newCache;
    bool cacheEnabled = false;
    while (1)
    {
        string command;
        cin >> command;
        if (command == "load")
        {
            string file;
            cin >> file;
            loadProgram(file, cacheEnabled, newCache);
            cout << endl;
        }
        else if (command == "run")
        {
            run(cacheEnabled, newCache);
            if (cacheEnabled)
                printCacheStats(newCache);
            cout << endl;
        }
        else if (command == "regs")
        {
            printRegs();
            cout << endl;
        }
        else if (command == "exit")
        {
            cout << "Exited the simulator" << endl;
            break;
        }
        else if (command == "mem")
        {
            string input1;
            string input2;
            cin >> input1;
            cin >> input2;
            unsigned long address;
            address = stoul(input1, nullptr, 16);
            int count;
            count = stoi(input2);
            printMem(address, count);
            cout << endl;
        }
        else if (command == "step")
        {
            step(cacheEnabled, newCache);
            cout << endl;
        }
        else if (command == "break")
        {
            int lineNumber;
            cin >> lineNumber;
            addBreakpoint(lineNumber);
            cout << endl;
        }
        else if (command == "del")
        {
            string temp;
            cin >> temp;
            if (temp != "break")
            {
                cout << "Invalid command" << endl;
                cout << endl;
                continue;
            }
            cin >> temp;
            int lineNumber = stoi(temp);
            removeBreakpoint(lineNumber);
            cout << endl;
        }
        else if (command == "show-stack")
        {
            showStack();
            cout << endl;
        }
        else if (command == "cache_sim")
        {
            string todo;
            cin >> todo;
            if (todo == "enable")
            {
                cacheEnabled = true;
                string file_name;
                cin >> file_name;
                newCache = enableCache(file_name);
                cout << endl;
            }
            else if (todo == "disable")
            {
                free(newCache);
                cacheEnabled = false;
                cout << endl;
            }
            else if (todo == "status")
            {
                if (cacheEnabled)
                {
                    printCacheStatus(newCache);
                }
                else
                {
                    cout << "Cache is disabled" << endl;
                }
                cout << endl;
            }
            else if (todo == "invalidate")
            {
                validateDirty(newCache);
                invalidateCache(newCache);
                cout << endl;
            }
            else if (todo == "dump")
            {
                string file_name;
                cin >> file_name;
                dumpCache(newCache, file_name);
                cout << endl;
            }
            else if (todo == "stats")
            {
                if (cacheEnabled)
                    printCacheStats(newCache);
                else
                    cout << "Cache is disabled" << endl;
                cout << endl;
            }
            else
            {
                cout << "Invalid command" << endl;
                cout << endl;
                continue;
            }
        }
        else
        {
            cout << "Invalid command" << endl;
            cout << endl;
            continue;
        }
    }
    return 0;
}